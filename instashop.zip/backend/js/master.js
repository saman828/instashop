$(document).ready(function() {
    $('body [inplace]').each(function() {
		var selection = [ "update-service-type", "update-user-status", "update-category-auto", "update-category-validation", "update-discount-category", "update-comment-status", "update-status-category", "update-user-grade" ];
		var change = { "update-service-type" : defined_services, "update-user-status" : defined_status, "update-category-auto" : cats, "update-category-validation" : validation, "update-discount-category" : defined_services, "update-comment-status" : defined_status, "update-status-category" : defined_status_cat, "update-user-grade" : grades};
        id = $(this).attr('inplace');

		if (selection.indexOf($(this).attr('what')) > -1) {
		    $('#' + $(this).attr('id')).editable({
				url: url,
				type: 'select',
				pk: id,
				name: $(this).attr('what'),
				source: change[$(this).attr('what')] ,
				title : 'مقدار را انتخاب کنید'
			});
		} else {
			$('#' + $(this).attr('id')).editable({
				url: url,
				type: 'text',
				pk: id,
				name: $(this).attr('what'),
				title : 'مقدار را وارد کنید',
				defaultValue : ($(this).attr('data-about') ? $(this).attr('data-about') : '')
			});
		}
    });

	$('body [data-id]').click(function() {
		$('.modal-body').html('<img src="' + loader + '" />');
		$('.modal-title').html('...');
		var comment_id = $(this).attr('data-id');
		params = {
			what: 'comment',
			id: comment_id,
			_token: token,
		};
		$.ajax({
			url : url,
			type : 'POST',
			data : params,
			success : function(result){
				var myArr = JSON.parse(result);
				$('.modal-body').html(myArr['comment']);
				$('.modal-title').html(myArr['sender'] + ' گفته :');
			},
		});
    });

	$('body [data-id]').click(function() {
		$('.modal-body').html('<img src="' + loader + '" />');
		$('.modal-title').html('...');
		var comment_id = $(this).attr('data-id');
		params = {
			what: 'comment',
			id: comment_id,
			_token: token,
		};
		$.ajax({
			url : url,
			type : 'POST',
			data : params,
			success : function(result){
				var myArr = JSON.parse(result);
				$('.modal-body').html(myArr['comment']);
				$('.modal-title').html(myArr['sender'] + ' گفته :');
			},
		});
    });

	$('body [data-description]').click(function() {
		var description_id = $(this).attr('data-description');
		$('#callback').html('');
		$('textarea[name=description]').val('...');
		$('input[name=description_id]').val(description_id);
		params = {
			what: 'description',
			id: description_id,
			_token: token,
		};
		$.ajax({
			url : url,
			type : 'POST',
			data : params,
			success : function(result){
				var myArr = JSON.parse(result);
				$('textarea[name=description]').val(myArr['description']);
			},
		});
    });

	$("#loading").css("display", "none");
	$("#submit").click(function(event){
		if( $('#select-to').length ) {
			$('#select-to option').prop('selected', true);
		}

		var data = $('#' + ajaxID).serialize();
		$('#submit').css("display", "none");
		$("#loading").css("display", "block");
		$('#submit').attr('disabled', 'true');
		$("#callback").html('');
		$.ajax({
			url : $('#' + ajaxID).attr('action'),
			type : $('#' + ajaxID).attr('method'),
			data : data,
			success : function(result){
				if( $('#select-to').length ) {
					$('#select-to option').prop('selected', false);
				}
				$("#callback").html(result);
				$("#loading").css("display", "none");
				$("#submit").removeAttr('disabled');
				$('#submit').css("display", "block");
			},
		});
		event.preventDefault();
	});
	$('#btn-up').bind('click', function() {
        $('#select-to option:selected').each( function() {
            var newPos = $('#select-to option').index(this) - 1;
            if (newPos > -1) {
                $('#select-to option').eq(newPos).before("<option value='"+$(this).val()+"' selected='selected'>"+$(this).text()+"</option>");
                $(this).remove();
            }
        });
    });
    $('#btn-down').bind('click', function() {
        var countOptions = $('#select-to option').size();
        $('#select-to option:selected').each( function() {
            var newPos = $('#select-to option').index(this) + 1;
            if (newPos < countOptions) {
                $('#select-to option').eq(newPos).after("<option value='"+$(this).val()+"' selected='selected'>"+$(this).text()+"</option>");
                $(this).remove();
            }
        });
    });
});
function deleteit(i, j) {
    $('#del_' + i).html('<img src="' + loader + '" />');
	$('#del_' + i + ' img').css({'border-radius':'15px'});
	params = {
		what: 'delete',
		who: j,
		delete: i,
		_token: token,
	};
	$.ajax({
		url : url,
		type : 'POST',
		data : params,
		success : function(result){
			$('#tr_' + i).fadeOut(1000, function() {
				$(this).remove();
			});
		},
	});
}
// COPY TO CLIPBOARD
// Attempts to use .execCommand('copy') on a created text field
// Falls back to a selectable alert if not supported
// Attempts to display status in Bootstrap tooltip
// ------------------------------------------------------------------------------

function copyToClipboard(text, el) {
  var copyTest = document.queryCommandSupported('copy');
  var elOriginalText = el.attr('data-original-title');

  if (copyTest === true) {
    var copyTextArea = document.createElement("textarea");
    copyTextArea.value = text;
    document.body.appendChild(copyTextArea);
    copyTextArea.select();
    try {
      var successful = document.execCommand('copy');
      var msg = successful ? 'کپی شد !' : 'عدم کپی !';
      el.attr('data-original-title', msg).tooltip('show');
    } catch (err) {
      console.log('عدم کپی !');
    }
    document.body.removeChild(copyTextArea);
    el.attr('data-original-title', elOriginalText);
  } else {
    // Fallback if browser doesn't support .execCommand('copy')
    window.prompt("Copy to clipboard: Ctrl+C or Command+C, Enter", text);
  }
}

$(document).ready(function() {
  // Initialize
  // ---------------------------------------------------------------------

  // Tooltips
  // Requires Bootstrap 3 for functionality
  $('.js-tooltip').tooltip();

  // Copy to clipboard
  // Grab any text in the attribute 'data-copy' and pass it to the 
  // copy function
  $('.js-copy').click(function() {
    var text = $(this).attr('data-copy');
    var el = $(this);
    copyToClipboard(text, el);
  });
});